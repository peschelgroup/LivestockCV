def hello():
    return print("hello world"")
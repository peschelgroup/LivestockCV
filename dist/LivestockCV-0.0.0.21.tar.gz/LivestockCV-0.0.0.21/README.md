# Livestock CV 

### Goals: 
Create one Python package to assist animal scientists and agricultural engineers in analyzing image and video of livestock animals

##### Contact:
Ryan L. Jeon, Iowa State University
ryanjeon@iastate.edu